import 'fighter_stats.dart';
import 'fighting_style.dart';
import 'weight_class.dart';

class Opponent {
  const Opponent({
    required this.name,
    required this.country,
    required this.age,
    required this.weightClass,
    required this.style,
    required this.stats,
    required this.wins,
    required this.losses,
  });

  final String name;
  final String country;
  final int age;
  final WeightClass weightClass;
  final FightingStyle style;
  final FighterStats stats;
  final int wins;
  final int losses;

  String get record => '$wins-$losses';
}
