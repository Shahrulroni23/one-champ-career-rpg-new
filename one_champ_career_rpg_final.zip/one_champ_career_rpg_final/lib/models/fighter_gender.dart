enum FighterGender {
  male,
  female,
}

extension FighterGenderExtension on FighterGender {
  String get displayName {
    switch (this) {
      case FighterGender.male:
        return 'MALE';
      case FighterGender.female:
        return 'FEMALE';
    }
  }
}
