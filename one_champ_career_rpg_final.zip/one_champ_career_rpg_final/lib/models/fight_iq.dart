enum FightIQ {
  low,
  average,
  high,
}

extension FightIQExtension on FightIQ {
  String get displayName {
    switch (this) {
      case FightIQ.low:
        return 'LOW';
      case FightIQ.average:
        return 'AVERAGE';
      case FightIQ.high:
        return 'HIGH';
    }
  }
}
