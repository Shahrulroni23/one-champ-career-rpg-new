class FighterStats {
  const FighterStats({
    required this.power,
    required this.speed,
    required this.strength,
    required this.cardio,
    required this.recovery,
    required this.chin,
    required this.heart,
    required this.durability,
    required this.jab,
    required this.cross,
    required this.hook,
    required this.kick,
    required this.elbow,
    required this.knee,
    required this.accuracy,
    required this.defense,
    required this.footwork,
    required this.wrestling,
    required this.clinch,
    required this.takedown,
    required this.takedownDefense,
    required this.groundControl,
    required this.grappling,
    required this.submission,
    required this.submissionDefense,
    required this.scramble,
    required this.fightIQ,
    required this.composure,
    required this.killerInstinct,
  });

  final int power;
  final int speed;
  final int strength;
  final int cardio;
  final int recovery;
  final int chin;
  final int heart;
  final int durability;

  final int jab;
  final int cross;
  final int hook;
  final int kick;
  final int elbow;
  final int knee;
  final int accuracy;
  final int defense;
  final int footwork;

  final int wrestling;
  final int clinch;
  final int takedown;
  final int takedownDefense;
  final int groundControl;

  final int grappling;
  final int submission;
  final int submissionDefense;
  final int scramble;

  final int fightIQ;
  final int composure;
  final int killerInstinct;

  FighterStats copyWith({
    int? power,
    int? speed,
    int? strength,
    int? cardio,
    int? recovery,
    int? chin,
    int? heart,
    int? durability,
    int? jab,
    int? cross,
    int? hook,
    int? kick,
    int? elbow,
    int? knee,
    int? accuracy,
    int? defense,
    int? footwork,
    int? wrestling,
    int? clinch,
    int? takedown,
    int? takedownDefense,
    int? groundControl,
    int? grappling,
    int? submission,
    int? submissionDefense,
    int? scramble,
    int? fightIQ,
    int? composure,
    int? killerInstinct,
  }) {
    return FighterStats(
      power: power ?? this.power,
      speed: speed ?? this.speed,
      strength: strength ?? this.strength,
      cardio: cardio ?? this.cardio,
      recovery: recovery ?? this.recovery,
      chin: chin ?? this.chin,
      heart: heart ?? this.heart,
      durability: durability ?? this.durability,
      jab: jab ?? this.jab,
      cross: cross ?? this.cross,
      hook: hook ?? this.hook,
      kick: kick ?? this.kick,
      elbow: elbow ?? this.elbow,
      knee: knee ?? this.knee,
      accuracy: accuracy ?? this.accuracy,
      defense: defense ?? this.defense,
      footwork: footwork ?? this.footwork,
      wrestling: wrestling ?? this.wrestling,
      clinch: clinch ?? this.clinch,
      takedown: takedown ?? this.takedown,
      takedownDefense: takedownDefense ?? this.takedownDefense,
      groundControl: groundControl ?? this.groundControl,
      grappling: grappling ?? this.grappling,
      submission: submission ?? this.submission,
      submissionDefense: submissionDefense ?? this.submissionDefense,
      scramble: scramble ?? this.scramble,
      fightIQ: fightIQ ?? this.fightIQ,
      composure: composure ?? this.composure,
      killerInstinct: killerInstinct ?? this.killerInstinct,
    );
  }

  int get overall {
    final values = <int>[
      power, speed, strength, cardio, recovery, chin, heart, durability,
      jab, cross, hook, kick, elbow, knee, accuracy, defense, footwork,
      wrestling, clinch, takedown, takedownDefense, groundControl,
      grappling, submission, submissionDefense, scramble,
      fightIQ, composure, killerInstinct,
    ];

    return (values.reduce((a, b) => a + b) / values.length).round();
  }
}
