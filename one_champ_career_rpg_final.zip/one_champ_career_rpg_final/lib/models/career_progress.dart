class CareerProgress {
  const CareerProgress({
    required this.wins,
    required this.losses,
    required this.draws,
    required this.money,
    required this.fans,
    required this.popularity,
    required this.rank,
    required this.startYear,
    required this.gymLevel,
    required this.championships,
    required this.titleDefenses,
    required this.legacy,
  });

  final int wins;
  final int losses;
  final int draws;
  final int money;
  final int fans;
  final int popularity;
  final int rank;
  final int startYear;
  final int gymLevel;
  final int championships;
  final int titleDefenses;
  final int legacy;

  CareerProgress copyWith({
    int? wins,
    int? losses,
    int? draws,
    int? money,
    int? fans,
    int? popularity,
    int? rank,
    int? startYear,
    int? gymLevel,
    int? championships,
    int? titleDefenses,
    int? legacy,
  }) {
    return CareerProgress(
      wins: wins ?? this.wins,
      losses: losses ?? this.losses,
      draws: draws ?? this.draws,
      money: money ?? this.money,
      fans: fans ?? this.fans,
      popularity: popularity ?? this.popularity,
      rank: rank ?? this.rank,
      startYear: startYear ?? this.startYear,
      gymLevel: gymLevel ?? this.gymLevel,
      championships: championships ?? this.championships,
      titleDefenses: titleDefenses ?? this.titleDefenses,
      legacy: legacy ?? this.legacy,
    );
  }

  static const CareerProgress beginner = CareerProgress(
    wins: 0,
    losses: 0,
    draws: 0,
    money: 0,
    fans: 0,
    popularity: 1,
    rank: 0,
    startYear: 2026,
    gymLevel: 1,
    championships: 0,
    titleDefenses: 0,
    legacy: 0,
  );

  String get record => '$wins-$losses-$draws';

  String get gymName {
    switch (gymLevel) {
      case 1: return 'Local Gym';
      case 2: return 'Regional Gym';
      case 3: return 'Elite Performance Centre';
      default: return 'World Class Fight Lab';
    }
  }

  int get trainingBonus {
    switch (gymLevel) {
      case 1: return 0;
      case 2: return 1;
      case 3: return 1;
      default: return 2;
    }
  }
}
