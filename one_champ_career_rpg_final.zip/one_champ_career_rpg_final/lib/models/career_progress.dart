class CareerProgress {
  const CareerProgress({
    required this.wins,
    required this.losses,
    required this.draws,
    required this.money,
    required this.fans,
    required this.popularity,
    required this.rank,
  });

  final int wins;
  final int losses;
  final int draws;
  final int money;
  final int fans;
  final int popularity;
  final int rank;

  CareerProgress copyWith({
    int? wins,
    int? losses,
    int? draws,
    int? money,
    int? fans,
    int? popularity,
    int? rank,
  }) {
    return CareerProgress(
      wins: wins ?? this.wins,
      losses: losses ?? this.losses,
      draws: draws ?? this.draws,
      money: money ?? this.money,
      fans: fans ?? this.fans,
      popularity: popularity ?? this.popularity,
      rank: rank ?? this.rank,
    );
  }

  static const CareerProgress beginner = CareerProgress(
    wins: 0,
    losses: 0,
    draws: 0,
    money: 0,
    fans: 0,
    popularity: 1,
    rank: 0,
  );

  String get record => '$wins-$losses-$draws';
}
