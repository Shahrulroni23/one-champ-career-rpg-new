enum FightingStyle {
  balanced,
  pressureFighter,
  counterFighter,
  technicalStriker,
  powerPuncher,
  powerKicker,
  clinchSpecialist,
  wrestler,
  submissionHunter,
}

extension FightingStyleExtension on FightingStyle {
  String get displayName {
    switch (this) {
      case FightingStyle.balanced:
        return 'BALANCED';
      case FightingStyle.pressureFighter:
        return 'PRESSURE FIGHTER';
      case FightingStyle.counterFighter:
        return 'COUNTER FIGHTER';
      case FightingStyle.technicalStriker:
        return 'TECHNICAL STRIKER';
      case FightingStyle.powerPuncher:
        return 'POWER PUNCHER';
      case FightingStyle.powerKicker:
        return 'POWER KICKER';
      case FightingStyle.clinchSpecialist:
        return 'CLINCH SPECIALIST';
      case FightingStyle.wrestler:
        return 'WRESTLER';
      case FightingStyle.submissionHunter:
        return 'SUBMISSION HUNTER';
    }
  }
}
