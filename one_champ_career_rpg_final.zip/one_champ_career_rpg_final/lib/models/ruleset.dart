enum Ruleset {
  mma,
  muayThai,
  kickboxing,
}

extension RulesetExtension on Ruleset {
  String get displayName {
    switch (this) {
      case Ruleset.mma:
        return 'MMA';
      case Ruleset.muayThai:
        return 'MUAY THAI';
      case Ruleset.kickboxing:
        return 'KICKBOXING';
    }
  }
}
