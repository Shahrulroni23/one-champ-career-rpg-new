enum FightOutcome {
  win,
  loss,
  draw,
}

class FightResult {
  const FightResult({
    required this.outcome,
    required this.method,
    required this.round,
    required this.summary,
    required this.purse,
    required this.fansChange,
  });

  final FightOutcome outcome;
  final String method;
  final int round;
  final List<String> summary;
  final int purse;
  final int fansChange;
}
