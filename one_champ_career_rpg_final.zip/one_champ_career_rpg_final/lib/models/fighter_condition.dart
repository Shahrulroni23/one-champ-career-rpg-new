class FighterCondition {
  const FighterCondition({
    required this.energy,
    required this.health,
    required this.morale,
    required this.weight,
    required this.year,
    required this.week,
    required this.day,
  });

  final int energy;
  final int health;
  final int morale;
  final double weight;
  final int year;
  final int week;
  final int day;

  FighterCondition copyWith({
    int? energy,
    int? health,
    int? morale,
    double? weight,
    int? year,
    int? week,
    int? day,
  }) {
    return FighterCondition(
      energy: energy ?? this.energy,
      health: health ?? this.health,
      morale: morale ?? this.morale,
      weight: weight ?? this.weight,
      year: year ?? this.year,
      week: week ?? this.week,
      day: day ?? this.day,
    );
  }

  static const FighterCondition beginner = FighterCondition(
    energy: 100,
    health: 100,
    morale: 80,
    weight: 70.0,
    year: 2026,
    week: 1,
    day: 1,
  );
}
