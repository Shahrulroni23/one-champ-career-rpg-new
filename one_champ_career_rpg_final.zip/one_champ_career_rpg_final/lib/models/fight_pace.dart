enum FightPace {
  slow,
  balanced,
  fast,
}

extension FightPaceExtension on FightPace {
  String get displayName {
    switch (this) {
      case FightPace.slow:
        return 'SLOW';
      case FightPace.balanced:
        return 'BALANCED';
      case FightPace.fast:
        return 'FAST';
    }
  }
}
