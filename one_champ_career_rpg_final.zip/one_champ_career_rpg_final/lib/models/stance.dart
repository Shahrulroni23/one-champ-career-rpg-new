enum Stance {
  orthodox,
  southpaw,
  switchStance,
}

extension StanceExtension on Stance {
  String get displayName {
    switch (this) {
      case Stance.orthodox:
        return 'ORTHODOX';
      case Stance.southpaw:
        return 'SOUTHPAW';
      case Stance.switchStance:
        return 'SWITCH';
    }
  }
}
