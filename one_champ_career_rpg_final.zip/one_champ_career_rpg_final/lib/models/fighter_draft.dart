import 'aggression.dart';
import 'career_progress.dart';
import 'fight_iq.dart';
import 'fight_pace.dart';
import 'fighter_condition.dart';
import 'fighter_gender.dart';
import 'fighter_stats.dart';
import 'fighting_style.dart';
import 'ruleset.dart';
import 'stance.dart';
import 'weight_class.dart';

class FighterDraft {
  FighterDraft({
    required this.ruleset,
    required this.name,
    required this.nickname,
    required this.country,
    required this.gender,
    required this.age,
    required this.weightClass,
    required this.height,
    required this.reach,
    required this.stance,
    required this.fightingStyle,
    required this.fightPace,
    required this.fightIQ,
    required this.aggression,
    required this.stats,
    required this.condition,
    required this.progress,
  });

  final Ruleset ruleset;
  final String name;
  final String nickname;
  final String country;
  final FighterGender gender;
  final int age;
  final WeightClass weightClass;
  final int height;
  final int reach;
  final Stance stance;
  final FightingStyle fightingStyle;
  final FightPace fightPace;
  final FightIQ fightIQ;
  final Aggression aggression;
  final FighterStats stats;
  final FighterCondition condition;
  final CareerProgress progress;

  FighterDraft copyWith({
    Ruleset? ruleset,
    String? name,
    String? nickname,
    String? country,
    FighterGender? gender,
    int? age,
    WeightClass? weightClass,
    int? height,
    int? reach,
    Stance? stance,
    FightingStyle? fightingStyle,
    FightPace? fightPace,
    FightIQ? fightIQ,
    Aggression? aggression,
    FighterStats? stats,
    FighterCondition? condition,
    CareerProgress? progress,
  }) {
    return FighterDraft(
      ruleset: ruleset ?? this.ruleset,
      name: name ?? this.name,
      nickname: nickname ?? this.nickname,
      country: country ?? this.country,
      gender: gender ?? this.gender,
      age: age ?? this.age,
      weightClass: weightClass ?? this.weightClass,
      height: height ?? this.height,
      reach: reach ?? this.reach,
      stance: stance ?? this.stance,
      fightingStyle: fightingStyle ?? this.fightingStyle,
      fightPace: fightPace ?? this.fightPace,
      fightIQ: fightIQ ?? this.fightIQ,
      aggression: aggression ?? this.aggression,
      stats: stats ?? this.stats,
      condition: condition ?? this.condition,
      progress: progress ?? this.progress,
    );
  }
}
