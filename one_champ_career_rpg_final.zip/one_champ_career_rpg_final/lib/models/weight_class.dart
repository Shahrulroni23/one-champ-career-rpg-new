enum WeightClass {
  strawweight,
  flyweight,
  bantamweight,
  featherweight,
  lightweight,
  welterweight,
  middleweight,
  lightHeavyweight,
  heavyweight,
}

extension WeightClassExtension on WeightClass {
  String get displayName {
    switch (this) {
      case WeightClass.strawweight:
        return 'STRAWWEIGHT';
      case WeightClass.flyweight:
        return 'FLYWEIGHT';
      case WeightClass.bantamweight:
        return 'BANTAMWEIGHT';
      case WeightClass.featherweight:
        return 'FEATHERWEIGHT';
      case WeightClass.lightweight:
        return 'LIGHTWEIGHT';
      case WeightClass.welterweight:
        return 'WELTERWEIGHT';
      case WeightClass.middleweight:
        return 'MIDDLEWEIGHT';
      case WeightClass.lightHeavyweight:
        return 'LIGHT HEAVYWEIGHT';
      case WeightClass.heavyweight:
        return 'HEAVYWEIGHT';
    }
  }

  double get targetWeightKg {
    switch (this) {
      case WeightClass.strawweight:
        return 52.2;
      case WeightClass.flyweight:
        return 56.7;
      case WeightClass.bantamweight:
        return 61.2;
      case WeightClass.featherweight:
        return 65.8;
      case WeightClass.lightweight:
        return 70.3;
      case WeightClass.welterweight:
        return 77.1;
      case WeightClass.middleweight:
        return 83.9;
      case WeightClass.lightHeavyweight:
        return 93.0;
      case WeightClass.heavyweight:
        return 110.0;
    }
  }
}
