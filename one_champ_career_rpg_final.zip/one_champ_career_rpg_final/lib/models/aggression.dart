enum Aggression {
  low,
  medium,
  high,
}

extension AggressionExtension on Aggression {
  String get displayName {
    switch (this) {
      case Aggression.low:
        return 'LOW';
      case Aggression.medium:
        return 'MEDIUM';
      case Aggression.high:
        return 'HIGH';
    }
  }
}
