import '../models/fighter_stats.dart';
import '../models/fighting_style.dart';

class FighterStatsGenerator {
  FighterStatsGenerator._();

  static FighterStats generate(FightingStyle style) {
    final baseStats = _balancedStats();

    switch (style) {
      case FightingStyle.balanced:
        return baseStats;
      case FightingStyle.pressureFighter:
        return baseStats.copyWith(
          power: 65,
          strength: 64,
          cardio: 69,
          chin: 68,
          heart: 72,
          durability: 67,
          cross: 65,
          hook: 67,
          knee: 63,
          clinch: 62,
          defense: 53,
          footwork: 55,
          fightIQ: 57,
          composure: 58,
          killerInstinct: 74,
        );
      case FightingStyle.counterFighter:
        return baseStats.copyWith(
          speed: 68,
          recovery: 62,
          jab: 65,
          cross: 66,
          kick: 64,
          accuracy: 71,
          defense: 72,
          footwork: 70,
          takedownDefense: 62,
          fightIQ: 74,
          composure: 72,
          killerInstinct: 55,
        );
      case FightingStyle.technicalStriker:
        return baseStats.copyWith(
          speed: 67,
          cardio: 64,
          jab: 70,
          cross: 69,
          hook: 65,
          kick: 72,
          elbow: 63,
          knee: 64,
          accuracy: 73,
          defense: 68,
          footwork: 71,
          fightIQ: 72,
          composure: 69,
        );
      case FightingStyle.powerPuncher:
        return baseStats.copyWith(
          power: 75,
          strength: 69,
          chin: 65,
          jab: 63,
          cross: 75,
          hook: 76,
          kick: 52,
          elbow: 58,
          accuracy: 64,
          defense: 54,
          footwork: 57,
          killerInstinct: 72,
        );
      case FightingStyle.powerKicker:
        return baseStats.copyWith(
          power: 72,
          speed: 64,
          strength: 66,
          jab: 55,
          cross: 57,
          kick: 76,
          knee: 70,
          accuracy: 66,
          defense: 57,
          footwork: 65,
          killerInstinct: 68,
        );
      case FightingStyle.clinchSpecialist:
        return baseStats.copyWith(
          strength: 68,
          cardio: 68,
          recovery: 63,
          chin: 66,
          heart: 68,
          durability: 66,
          elbow: 70,
          knee: 72,
          defense: 62,
          wrestling: 64,
          clinch: 76,
          takedown: 59,
          takedownDefense: 65,
          groundControl: 64,
          composure: 66,
        );
      case FightingStyle.wrestler:
        return baseStats.copyWith(
          strength: 72,
          cardio: 69,
          recovery: 65,
          heart: 68,
          jab: 50,
          cross: 52,
          hook: 51,
          kick: 46,
          wrestling: 76,
          clinch: 69,
          takedown: 77,
          takedownDefense: 72,
          groundControl: 73,
          grappling: 67,
          submission: 59,
          submissionDefense: 66,
          scramble: 70,
          fightIQ: 66,
        );
      case FightingStyle.submissionHunter:
        return baseStats.copyWith(
          cardio: 66,
          recovery: 64,
          jab: 48,
          cross: 49,
          hook: 47,
          kick: 45,
          wrestling: 66,
          clinch: 64,
          takedown: 63,
          takedownDefense: 65,
          groundControl: 70,
          grappling: 76,
          submission: 78,
          submissionDefense: 73,
          scramble: 74,
          fightIQ: 71,
          composure: 68,
        );
    }
  }

  static FighterStats _balancedStats() {
    return const FighterStats(
      power: 60,
      speed: 60,
      strength: 60,
      cardio: 60,
      recovery: 60,
      chin: 60,
      heart: 60,
      durability: 60,
      jab: 60,
      cross: 60,
      hook: 60,
      kick: 60,
      elbow: 60,
      knee: 60,
      accuracy: 60,
      defense: 60,
      footwork: 60,
      wrestling: 60,
      clinch: 60,
      takedown: 60,
      takedownDefense: 60,
      groundControl: 60,
      grappling: 60,
      submission: 60,
      submissionDefense: 60,
      scramble: 60,
      fightIQ: 60,
      composure: 60,
      killerInstinct: 60,
    );
  }
}
