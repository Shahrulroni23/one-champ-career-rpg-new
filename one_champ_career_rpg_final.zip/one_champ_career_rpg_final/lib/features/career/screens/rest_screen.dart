import 'package:flutter/material.dart';

import '../../../models/fighter_draft.dart';
import '../services/career_save_service.dart';
import '../services/condition_service.dart';
import 'career_dashboard_screen.dart';

class RestScreen extends StatefulWidget {
  const RestScreen({
    required this.fighter,
    super.key,
  });

  final FighterDraft fighter;

  @override
  State<RestScreen> createState() => _RestScreenState();
}

class _RestScreenState extends State<RestScreen> {
  bool _isResting = false;

  String _dayName(int day) {
    const days = [
      'Monday', 'Tuesday', 'Wednesday', 'Thursday',
      'Friday', 'Saturday', 'Sunday',
    ];
    return days[day.clamp(1, 7) - 1];
  }

  Future<void> _rest() async {
    if (_isResting) return;
    setState(() => _isResting = true);

    final updatedFighter = widget.fighter.copyWith(
      condition: ConditionService.rest(widget.fighter.condition),
    );

    await CareerSaveService.saveCareer(updatedFighter);
    if (!mounted) return;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('REST COMPLETE'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.hotel, size: 48),
              const SizedBox(height: 16),
              const Text(
                'RECOVERY DAY',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Energy +30\nHealth +12\nMorale +5',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Text(
                '${_dayName(updatedFighter.condition.day)} • '
                'Week ${updatedFighter.condition.week} • '
                '${updatedFighter.condition.year}',
              ),
            ],
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('CONTINUE'),
            ),
          ],
        );
      },
    );

    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute<void>(
        builder: (_) => CareerDashboardScreen(fighter: updatedFighter),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('REST DAY')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Spacer(),
            const Icon(Icons.hotel, size: 80),
            const SizedBox(height: 20),
            const Text(
              'TAKE A REST DAY',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Energy ${widget.fighter.condition.energy} / 100\n'
              'Health ${widget.fighter.condition.health} / 100\n'
              'Morale ${widget.fighter.condition.morale} / 100',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: _isResting ? null : _rest,
              child: const Text('REST NOW'),
            ),
            const SizedBox(height: 16),
            OutlinedButton(
              onPressed: _isResting ? null : () => Navigator.pop(context),
              child: const Text('BACK'),
            ),
            const Spacer(),
          ],
        ),
      ),
    );
  }
}
