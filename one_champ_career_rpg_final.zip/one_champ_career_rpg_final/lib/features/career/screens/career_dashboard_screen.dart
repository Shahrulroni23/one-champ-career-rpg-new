import 'package:flutter/material.dart';

import '../../../models/fighter_draft.dart';
import '../../../models/ruleset.dart';
import '../../../models/weight_class.dart';
import '../../training/screens/training_screen.dart';
import 'fight_offer_screen.dart';
import 'fighter_profile_screen.dart';
import 'gym_screen.dart';
import 'news_screen.dart';
import 'rest_screen.dart';

class CareerDashboardScreen extends StatelessWidget {
  const CareerDashboardScreen({required this.fighter, super.key});
  final FighterDraft fighter;

  DateTime get _careerDate {
    final dayOffset = ((fighter.condition.week - 1) * 7) + (fighter.condition.day - 1);
    return DateTime(fighter.condition.year, 1, 1).add(Duration(days: dayOffset));
  }

  int get _careerAge => fighter.age + (fighter.condition.year - fighter.progress.startYear);

  String _monthName(int month) {
    const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    return months[month - 1];
  }

  int _average(List<int> values) => (values.reduce((a, b) => a + b) / values.length).round();

  @override
  Widget build(BuildContext context) {
    final date = _careerDate;
    final striking = _average([
      fighter.stats.jab, fighter.stats.cross, fighter.stats.hook,
      fighter.stats.kick, fighter.stats.elbow, fighter.stats.knee,
      fighter.stats.accuracy, fighter.stats.footwork,
    ]);
    final grappling = _average([
      fighter.stats.wrestling, fighter.stats.takedown, fighter.stats.groundControl,
      fighter.stats.grappling, fighter.stats.submission, fighter.stats.scramble,
    ]);
    final physical = _average([
      fighter.stats.power, fighter.stats.speed, fighter.stats.strength,
      fighter.stats.cardio, fighter.stats.recovery, fighter.stats.durability,
    ]);
    final mental = _average([
      fighter.stats.fightIQ, fighter.stats.composure, fighter.stats.killerInstinct,
    ]);

    return Scaffold(
      appBar: AppBar(
        title: const Text('ONE CAREER'),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
            icon: const Icon(Icons.home_outlined),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF2A1013), Color(0xFF111216)],
                ),
                border: Border.all(color: Colors.white12),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      const CircleAvatar(radius: 38, child: Icon(Icons.sports_mma, size: 38)),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(fighter.name.toUpperCase(),
                                style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
                            if (fighter.nickname.isNotEmpty)
                              Text('“${fighter.nickname}”', style: const TextStyle(color: Colors.white70)),
                            const SizedBox(height: 4),
                            Text('${fighter.ruleset.displayName} • ${fighter.weightClass.displayName}'),
                          ],
                        ),
                      ),
                      Column(
                        children: [
                          Text('${fighter.stats.overall}', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                          const Text('OVR', style: TextStyle(color: Colors.white54)),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _MiniLabel('RECORD', fighter.progress.record),
                      _MiniLabel('AGE', '$_careerAge'),
                      _MiniLabel('RANK', fighter.progress.rank == 0 ? 'NR' : '#${fighter.progress.rank}'),
                      _MiniLabel('LEGACY', '${fighter.progress.legacy}'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    const Icon(Icons.calendar_month, size: 34),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${date.day} ${_monthName(date.month)} ${date.year}',
                              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                          Text('Week ${fighter.condition.week} • Career year ${fighter.condition.year - fighter.progress.startYear + 1}',
                              style: const TextStyle(color: Colors.white60)),
                        ],
                      ),
                    ),
                    Text('\$${fighter.progress.money}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            _ConditionStrip(fighter: fighter),
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('FIGHTER IDENTITY', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(child: _SkillChip('STRIKING', striking)),
                      const SizedBox(width: 8),
                      Expanded(child: _SkillChip('GRAPPLING', grappling)),
                    ]),
                    const SizedBox(height: 8),
                    Row(children: [
                      Expanded(child: _SkillChip('PHYSICAL', physical)),
                      const SizedBox(width: 8),
                      Expanded(child: _SkillChip('MENTAL', mental)),
                    ]),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Card(
              child: ListTile(
                leading: const Icon(Icons.fitness_center),
                title: Text(fighter.progress.gymName, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('Gym Lv ${fighter.progress.gymLevel} • Training bonus +${fighter.progress.trainingBonus}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => GymScreen(fighter: fighter))),
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => TrainingScreen(fighter: fighter))),
                    icon: const Icon(Icons.fitness_center),
                    label: const Text('TRAIN'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => RestScreen(fighter: fighter))),
                    icon: const Icon(Icons.hotel),
                    label: const Text('REST'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            FilledButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => FightOfferScreen(fighter: fighter))),
              icon: const Icon(Icons.sports_mma),
              label: const Text('FIND FIGHT'),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => FighterProfileScreen(fighter: fighter))),
                    icon: const Icon(Icons.person_search),
                    label: const Text('PROFILE'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => NewsScreen(fighter: fighter))),
                    icon: const Icon(Icons.newspaper),
                    label: const Text('NEWS'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class _MiniLabel extends StatelessWidget {
  const _MiniLabel(this.label, this.value);
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Column(children: [
    Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
    Text(label, style: const TextStyle(fontSize: 10, color: Colors.white54)),
  ]);
}

class _ConditionStrip extends StatelessWidget {
  const _ConditionStrip({required this.fighter});
  final FighterDraft fighter;
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Row(children: [
        Expanded(child: _ConditionValue(Icons.bolt, 'ENERGY', fighter.condition.energy)),
        Expanded(child: _ConditionValue(Icons.favorite, 'HEALTH', fighter.condition.health)),
        Expanded(child: _ConditionValue(Icons.mood, 'MORALE', fighter.condition.morale)),
      ]),
    ),
  );
}

class _ConditionValue extends StatelessWidget {
  const _ConditionValue(this.icon, this.label, this.value);
  final IconData icon;
  final String label;
  final int value;
  @override
  Widget build(BuildContext context) => Column(children: [
    Icon(icon, size: 20), const SizedBox(height: 4),
    Text('$value', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
    Text(label, style: const TextStyle(fontSize: 10, color: Colors.white54)),
  ]);
}

class _SkillChip extends StatelessWidget {
  const _SkillChip(this.label, this.value);
  final String label;
  final int value;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
    decoration: BoxDecoration(
      color: Colors.white.withValues(alpha: 0.05),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: Colors.white10),
    ),
    child: Row(children: [
      Expanded(child: Text(label, style: const TextStyle(fontSize: 11, color: Colors.white60))),
      Text('$value', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    ]),
  );
}
