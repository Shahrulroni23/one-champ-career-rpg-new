import 'package:flutter/material.dart';

import '../../../models/fighter_draft.dart';
import '../../../models/ruleset.dart';
import '../../../models/weight_class.dart';
import '../../training/screens/training_screen.dart';
import 'fight_offer_screen.dart';
import 'rest_screen.dart';

class CareerDashboardScreen extends StatelessWidget {
  const CareerDashboardScreen({
    required this.fighter,
    super.key,
  });

  final FighterDraft fighter;

  String _dayName(int day) {
    const days = [
      'Monday', 'Tuesday', 'Wednesday', 'Thursday',
      'Friday', 'Saturday', 'Sunday',
    ];
    return days[day.clamp(1, 7) - 1];
  }

  String _popularityStars(int value) {
    final safe = value.clamp(1, 5);
    return '${'★' * safe}${'☆' * (5 - safe)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CAREER'),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            tooltip: 'Back to career menu',
            onPressed: () {
              Navigator.popUntil(context, (route) => route.isFirst);
            },
            icon: const Icon(Icons.home_outlined),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Card(
              elevation: 5,
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    const CircleAvatar(
                      radius: 45,
                      child: Icon(Icons.person, size: 50),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      fighter.name.toUpperCase(),
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (fighter.nickname.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        '"${fighter.nickname}"',
                        style: const TextStyle(color: Colors.white70),
                      ),
                    ],
                    const SizedBox(height: 8),
                    Text(
                      '${fighter.ruleset.displayName} • '
                      '${fighter.weightClass.displayName}',
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${_dayName(fighter.condition.day)} • '
                      'Week ${fighter.condition.week} • '
                      '${fighter.condition.year}',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _InfoCard(
                    title: 'Record',
                    value: fighter.progress.record,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _InfoCard(
                    title: 'OVR',
                    value: '${fighter.stats.overall}',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _InfoCard(
                    title: 'Money',
                    value: '\$${fighter.progress.money}',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _InfoCard(
                    title: 'Fans',
                    value: '${fighter.progress.fans}',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _InfoCard(
                    title: 'Popularity',
                    value: _popularityStars(fighter.progress.popularity),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _InfoCard(
                    title: 'Rank',
                    value: fighter.progress.rank == 0
                        ? 'UNRANKED'
                        : '#${fighter.progress.rank}',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            _ConditionCard(fighter: fighter),
            const SizedBox(height: 20),
            _StatsSection(
              title: 'PHYSICAL',
              stats: [
                _StatData('Power', fighter.stats.power),
                _StatData('Speed', fighter.stats.speed),
                _StatData('Strength', fighter.stats.strength),
                _StatData('Cardio', fighter.stats.cardio),
                _StatData('Recovery', fighter.stats.recovery),
                _StatData('Chin', fighter.stats.chin),
                _StatData('Heart', fighter.stats.heart),
                _StatData('Durability', fighter.stats.durability),
              ],
            ),
            const SizedBox(height: 14),
            _StatsSection(
              title: 'STRIKING',
              stats: [
                _StatData('Jab', fighter.stats.jab),
                _StatData('Cross', fighter.stats.cross),
                _StatData('Hook', fighter.stats.hook),
                _StatData('Kick', fighter.stats.kick),
                _StatData('Elbow', fighter.stats.elbow),
                _StatData('Knee', fighter.stats.knee),
                _StatData('Accuracy', fighter.stats.accuracy),
                _StatData('Defense', fighter.stats.defense),
                _StatData('Footwork', fighter.stats.footwork),
              ],
            ),
            const SizedBox(height: 14),
            _StatsSection(
              title: 'WRESTLING',
              stats: [
                _StatData('Wrestling', fighter.stats.wrestling),
                _StatData('Clinch', fighter.stats.clinch),
                _StatData('Takedown', fighter.stats.takedown),
                _StatData('Takedown Defense', fighter.stats.takedownDefense),
                _StatData('Ground Control', fighter.stats.groundControl),
              ],
            ),
            const SizedBox(height: 14),
            _StatsSection(
              title: 'GRAPPLING',
              stats: [
                _StatData('Grappling', fighter.stats.grappling),
                _StatData('Submission', fighter.stats.submission),
                _StatData(
                  'Submission Defense',
                  fighter.stats.submissionDefense,
                ),
                _StatData('Scramble', fighter.stats.scramble),
              ],
            ),
            const SizedBox(height: 14),
            _StatsSection(
              title: 'MENTAL',
              stats: [
                _StatData('Fight IQ', fighter.stats.fightIQ),
                _StatData('Composure', fighter.stats.composure),
                _StatData('Killer Instinct', fighter.stats.killerInstinct),
              ],
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => TrainingScreen(fighter: fighter),
                  ),
                );
              },
              icon: const Icon(Icons.fitness_center),
              label: const Text('TRAIN'),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => RestScreen(fighter: fighter),
                  ),
                );
              },
              icon: const Icon(Icons.hotel),
              label: const Text('REST'),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => FightOfferScreen(fighter: fighter),
                  ),
                );
              },
              icon: const Icon(Icons.sports_mma),
              label: const Text('FIND FIGHT'),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class _ConditionCard extends StatelessWidget {
  const _ConditionCard({required this.fighter});

  final FighterDraft fighter;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text(
              'FIGHTER CONDITION',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.3,
              ),
            ),
            const SizedBox(height: 16),
            _ConditionBar(
              title: 'Energy',
              value: fighter.condition.energy,
              icon: Icons.bolt,
            ),
            _ConditionBar(
              title: 'Health',
              value: fighter.condition.health,
              icon: Icons.favorite,
            ),
            _ConditionBar(
              title: 'Morale',
              value: fighter.condition.morale,
              icon: Icons.sentiment_satisfied_alt,
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                const Icon(Icons.monitor_weight_outlined),
                const SizedBox(width: 10),
                const Expanded(child: Text('Weight')),
                Text(
                  '${fighter.condition.weight.toStringAsFixed(1)} kg',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ConditionBar extends StatelessWidget {
  const _ConditionBar({
    required this.title,
    required this.value,
    required this.icon,
  });

  final String title;
  final int value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final safeValue = value.clamp(0, 100);

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        children: [
          Row(
            children: [
              Icon(icon),
              const SizedBox(width: 10),
              Expanded(child: Text(title)),
              Text(
                '$safeValue / 100',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 6),
          LinearProgressIndicator(
            value: safeValue / 100,
            minHeight: 9,
            borderRadius: BorderRadius.circular(10),
          ),
        ],
      ),
    );
  }
}

class _StatsSection extends StatelessWidget {
  const _StatsSection({
    required this.title,
    required this.stats,
  });

  final String title;
  final List<_StatData> stats;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.3,
              ),
            ),
            const SizedBox(height: 12),
            ...stats.map(
              (stat) => _StatRow(
                title: stat.title,
                value: stat.value,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatData {
  const _StatData(this.title, this.value);

  final String title;
  final int value;
}

class _StatRow extends StatelessWidget {
  const _StatRow({
    required this.title,
    required this.value,
  });

  final String title;
  final int value;

  @override
  Widget build(BuildContext context) {
    final safeValue = value.clamp(0, 99);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: Text(title)),
              Text(
                '$safeValue',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 5),
          LinearProgressIndicator(
            value: safeValue / 99,
            minHeight: 7,
            borderRadius: BorderRadius.circular(10),
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({
    required this.title,
    required this.value,
  });

  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: SizedBox(
        height: 90,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(title),
              const SizedBox(height: 6),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    value,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
