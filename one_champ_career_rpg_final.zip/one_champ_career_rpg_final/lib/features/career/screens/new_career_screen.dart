import 'package:flutter/material.dart';

import '../../character_creation/screens/ruleset_selection_screen.dart';

class NewCareerScreen extends StatelessWidget {
  const NewCareerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('NEW CAREER')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Spacer(),
            const Icon(Icons.person_add_alt_1, size: 72),
            const SizedBox(height: 20),
            const Text(
              'CREATE YOUR FIGHTER',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Start as an unknown prospect and build a career through training, fights, rankings and championships.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const RulesetSelectionScreen(),
                  ),
                );
              },
              child: const Text('CREATE FIGHTER'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: null,
              child: const Text('REAL FIGHTER CAREER — BACKLOG'),
            ),
            const Spacer(),
          ],
        ),
      ),
    );
  }
}
