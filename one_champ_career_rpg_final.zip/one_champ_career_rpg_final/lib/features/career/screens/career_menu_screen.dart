import 'package:flutter/material.dart';

import '../services/career_save_service.dart';
import 'career_dashboard_screen.dart';
import 'new_career_screen.dart';

class CareerMenuScreen extends StatefulWidget {
  const CareerMenuScreen({super.key});

  @override
  State<CareerMenuScreen> createState() => _CareerMenuScreenState();
}

class _CareerMenuScreenState extends State<CareerMenuScreen> {
  bool get _hasCareer => CareerSaveService.hasCareer();

  void _continueCareer() {
    final fighter = CareerSaveService.loadCareer();

    if (fighter == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No saved career found.')),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => CareerDashboardScreen(fighter: fighter),
      ),
    ).then((_) {
      if (mounted) setState(() {});
    });
  }

  Future<void> _deleteCareer() async {
    if (!_hasCareer) return;

    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('DELETE CAREER'),
          content: const Text(
            'This permanently deletes the current career save.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('CANCEL'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('DELETE'),
            ),
          ],
        );
      },
    );

    if (shouldDelete != true) return;

    await CareerSaveService.deleteCareer();
    if (!mounted) return;

    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Career save deleted.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CAREER')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 30),
            const Text(
              'CAREER MODE',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 50),
            if (_hasCareer) ...[
              ElevatedButton(
                onPressed: _continueCareer,
                child: const Text('CONTINUE CAREER'),
              ),
              const SizedBox(height: 16),
            ],
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const NewCareerScreen(),
                  ),
                ).then((_) {
                  if (mounted) setState(() {});
                });
              },
              child: const Text('NEW CAREER'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _hasCareer ? _deleteCareer : null,
              child: const Text('DELETE SAVE'),
            ),
            const Spacer(),
            OutlinedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('BACK'),
            ),
          ],
        ),
      ),
    );
  }
}
