import 'package:flutter/material.dart';
import '../../../models/fighter_draft.dart';
import '../../../models/fighting_style.dart';
import '../../../models/stance.dart';

class FighterProfileScreen extends StatelessWidget {
  const FighterProfileScreen({required this.fighter, super.key});
  final FighterDraft fighter;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('FIGHTER PROFILE')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const CircleAvatar(radius: 44, child: Icon(Icons.person, size: 48)),
                  const SizedBox(height: 14),
                  Text(fighter.name.toUpperCase(),
                      style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
                  if (fighter.nickname.isNotEmpty) Text('“${fighter.nickname}”'),
                  const SizedBox(height: 8),
                  Text('${fighter.country} • ${fighter.fightingStyle.displayName}'),
                  Text('${fighter.height} cm • ${fighter.reach} cm • ${fighter.stance.displayName}'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          _StatGroup('PHYSICAL', {
            'Power': fighter.stats.power, 'Speed': fighter.stats.speed,
            'Strength': fighter.stats.strength, 'Cardio': fighter.stats.cardio,
            'Recovery': fighter.stats.recovery, 'Chin': fighter.stats.chin,
            'Heart': fighter.stats.heart, 'Durability': fighter.stats.durability,
          }),
          _StatGroup('STRIKING', {
            'Jab': fighter.stats.jab, 'Cross': fighter.stats.cross,
            'Hook': fighter.stats.hook, 'Kick': fighter.stats.kick,
            'Elbow': fighter.stats.elbow, 'Knee': fighter.stats.knee,
            'Accuracy': fighter.stats.accuracy, 'Defense': fighter.stats.defense,
            'Footwork': fighter.stats.footwork,
          }),
          _StatGroup('WRESTLING / GRAPPLING', {
            'Wrestling': fighter.stats.wrestling, 'Clinch': fighter.stats.clinch,
            'Takedown': fighter.stats.takedown, 'Takedown Defense': fighter.stats.takedownDefense,
            'Ground Control': fighter.stats.groundControl, 'Grappling': fighter.stats.grappling,
            'Submission': fighter.stats.submission, 'Submission Defense': fighter.stats.submissionDefense,
            'Scramble': fighter.stats.scramble,
          }),
          _StatGroup('MENTAL', {
            'Fight IQ': fighter.stats.fightIQ,
            'Composure': fighter.stats.composure,
            'Killer Instinct': fighter.stats.killerInstinct,
          }),
        ],
      ),
    );
  }
}

class _StatGroup extends StatelessWidget {
  const _StatGroup(this.title, this.values);
  final String title;
  final Map<String, int> values;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ...values.entries.map((entry) {
              final value = entry.value.clamp(0, 99);
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Column(
                  children: [
                    Row(children: [Expanded(child: Text(entry.key)), Text('$value')]),
                    const SizedBox(height: 4),
                    LinearProgressIndicator(value: value / 99, minHeight: 6),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
