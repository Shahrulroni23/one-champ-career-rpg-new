import 'package:flutter/material.dart';

import '../../../models/fight_result.dart';
import '../../../models/fighter_draft.dart';
import '../../../models/fighting_style.dart';
import '../../../models/opponent.dart';
import '../../../models/weight_class.dart';
import '../services/career_save_service.dart';
import '../services/condition_service.dart';
import '../services/fight_engine.dart';
import '../services/opponent_generator.dart';
import 'career_dashboard_screen.dart';

class FightOfferScreen extends StatefulWidget {
  const FightOfferScreen({
    required this.fighter,
    super.key,
  });

  final FighterDraft fighter;

  @override
  State<FightOfferScreen> createState() => _FightOfferScreenState();
}

class _FightOfferScreenState extends State<FightOfferScreen> {
  late Opponent _opponent;
  bool _simulating = false;

  @override
  void initState() {
    super.initState();
    _opponent = OpponentGenerator.generate(widget.fighter);
  }

  void _newOffer() {
    setState(() {
      _opponent = OpponentGenerator.generate(widget.fighter);
    });
  }

  Future<void> _fight() async {
    if (_simulating) return;

    if (widget.fighter.condition.energy < 35 ||
        widget.fighter.condition.health < 50) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Condition too low. Rest before taking a fight.',
          ),
        ),
      );
      return;
    }

    setState(() => _simulating = true);

    final result = FightEngine.simulate(
      fighter: widget.fighter,
      opponent: _opponent,
    );

    final oldProgress = widget.fighter.progress;
    final updatedProgress = switch (result.outcome) {
      FightOutcome.win => oldProgress.copyWith(
          wins: oldProgress.wins + 1,
          money: oldProgress.money + result.purse,
          fans: oldProgress.fans + result.fansChange,
          popularity: (oldProgress.popularity + 1).clamp(1, 5),
          rank: oldProgress.rank == 0 ? 30 : (oldProgress.rank - 2).clamp(1, 30),
        ),
      FightOutcome.loss => oldProgress.copyWith(
          losses: oldProgress.losses + 1,
          money: oldProgress.money + (result.purse ~/ 2),
          fans: oldProgress.fans + result.fansChange,
          rank: oldProgress.rank == 0 ? 35 : (oldProgress.rank + 2).clamp(1, 50),
        ),
      FightOutcome.draw => oldProgress.copyWith(
          draws: oldProgress.draws + 1,
          money: oldProgress.money + (result.purse ~/ 2),
          fans: oldProgress.fans + result.fansChange,
        ),
    };

    final updatedFighter = widget.fighter.copyWith(
      progress: updatedProgress,
      condition: ConditionService.afterFight(
        widget.fighter.condition,
        won: result.outcome == FightOutcome.win,
      ),
    );

    await CareerSaveService.saveCareer(updatedFighter);
    if (!mounted) return;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        final outcomeText = switch (result.outcome) {
          FightOutcome.win => 'WIN',
          FightOutcome.loss => 'LOSS',
          FightOutcome.draw => 'DRAW',
        };

        return AlertDialog(
          title: Text(
            outcomeText,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '${widget.fighter.name} vs ${_opponent.name}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                Text('${result.method} • Round ${result.round}'),
                const SizedBox(height: 18),
                ...result.summary.map(
                  (line) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text(line),
                  ),
                ),
                const Divider(),
                Text('Purse: \$${result.purse}'),
                Text('Fans: +${result.fansChange}'),
              ],
            ),
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('CONTINUE'),
            ),
          ],
        );
      },
    );

    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute<void>(
        builder: (_) => CareerDashboardScreen(
          fighter: updatedFighter,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final stars = (_opponent.stats.overall / 20).ceil().clamp(1, 5);

    return Scaffold(
      appBar: AppBar(title: const Text('FIGHT OFFER')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const Text(
            'NEW FIGHT OFFER',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 30),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const CircleAvatar(
                    radius: 40,
                    child: Icon(Icons.sports_mma, size: 42),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    _opponent.name.toUpperCase(),
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text('${_opponent.country} • Age ${_opponent.age}'),
                  Text(_opponent.weightClass.displayName),
                  Text(_opponent.style.displayName),
                  const SizedBox(height: 12),
                  Text('Record ${_opponent.record}'),
                  Text('OVR ${_opponent.stats.overall}'),
                  Text('${'★' * stars}${'☆' * (5 - stars)}'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(
                    '${widget.fighter.name} — OVR ${widget.fighter.stats.overall}',
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Energy ${widget.fighter.condition.energy} • '
                    'Health ${widget.fighter.condition.health}',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: _simulating ? null : _fight,
            child: Text(_simulating ? 'SIMULATING...' : 'ACCEPT & FIGHT'),
          ),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: _simulating ? null : _newOffer,
            child: const Text('DECLINE / NEW OFFER'),
          ),
        ],
      ),
    );
  }
}
