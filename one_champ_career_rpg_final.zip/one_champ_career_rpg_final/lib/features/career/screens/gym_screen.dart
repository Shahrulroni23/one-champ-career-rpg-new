import 'package:flutter/material.dart';

import '../../../models/fighter_draft.dart';
import '../services/career_save_service.dart';
import 'career_dashboard_screen.dart';

class GymScreen extends StatefulWidget {
  const GymScreen({required this.fighter, super.key});
  final FighterDraft fighter;

  @override
  State<GymScreen> createState() => _GymScreenState();
}

class _GymScreenState extends State<GymScreen> {
  bool _busy = false;

  int _upgradeCost(int level) {
    switch (level) {
      case 1: return 1500;
      case 2: return 5000;
      case 3: return 15000;
      default: return 0;
    }
  }

  String _nextGym(int level) {
    switch (level) {
      case 1: return 'Regional Gym';
      case 2: return 'Elite Performance Centre';
      case 3: return 'World Class Fight Lab';
      default: return 'MAX LEVEL';
    }
  }

  Future<void> _upgrade() async {
    if (_busy || widget.fighter.progress.gymLevel >= 4) return;
    final cost = _upgradeCost(widget.fighter.progress.gymLevel);
    if (widget.fighter.progress.money < cost) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Need \$$cost to upgrade this gym.')),
      );
      return;
    }

    setState(() => _busy = true);
    final updated = widget.fighter.copyWith(
      progress: widget.fighter.progress.copyWith(
        money: widget.fighter.progress.money - cost,
        gymLevel: widget.fighter.progress.gymLevel + 1,
        legacy: widget.fighter.progress.legacy + 5,
      ),
    );
    await CareerSaveService.saveCareer(updated);
    if (!mounted) return;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('GYM UPGRADED'),
        content: Text(
          '${updated.progress.gymName}\n\nTraining development is now more efficient.',
          textAlign: TextAlign.center,
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('CONTINUE'),
          ),
        ],
      ),
    );
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute<void>(
        builder: (_) => CareerDashboardScreen(fighter: updated),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final level = widget.fighter.progress.gymLevel;
    final maxed = level >= 4;
    final cost = _upgradeCost(level);
    return Scaffold(
      appBar: AppBar(title: const Text('GYM HQ')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                children: [
                  const Icon(Icons.fitness_center, size: 58),
                  const SizedBox(height: 14),
                  Text(
                    widget.fighter.progress.gymName.toUpperCase(),
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text('GYM LEVEL $level / 4'),
                  const SizedBox(height: 18),
                  LinearProgressIndicator(value: level / 4, minHeight: 10),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const _FacilityTile(
            icon: Icons.monitor_heart_outlined,
            title: 'Conditioning Zone',
            text: 'Improves cardio, recovery and physical development.',
          ),
          const _FacilityTile(
            icon: Icons.sports_mma,
            title: 'Combat Floor',
            text: 'Better equipment improves technical training gains.',
          ),
          const _FacilityTile(
            icon: Icons.psychology_alt_outlined,
            title: 'Coaching Room',
            text: 'Higher gym levels improve Fight IQ and composure development.',
          ),
          const SizedBox(height: 20),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(maxed ? 'WORLD CLASS FACILITY' : 'NEXT: ${_nextGym(level)}',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                  const SizedBox(height: 8),
                  Text(maxed
                      ? 'Maximum gym level reached.'
                      : 'Upgrade cost: \$$cost\nCurrent cash: \$${widget.fighter.progress.money}'),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: maxed || _busy ? null : _upgrade,
                    child: Text(maxed ? 'MAX LEVEL' : 'UPGRADE GYM'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FacilityTile extends StatelessWidget {
  const _FacilityTile({required this.icon, required this.title, required this.text});
  final IconData icon;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(text),
      ),
    );
  }
}
