import 'package:flutter/material.dart';
import '../../../models/fighter_draft.dart';

class NewsScreen extends StatelessWidget {
  const NewsScreen({required this.fighter, super.key});
  final FighterDraft fighter;

  @override
  Widget build(BuildContext context) {
    final rankText = fighter.progress.rank == 0 ? 'unranked prospect' : '#${fighter.progress.rank} contender';
    final stories = <Map<String, String>>[
      {
        'title': '${fighter.name} enters the ${fighter.weightClass.displayName} scene',
        'body': 'The $rankText continues building a career in ${fighter.ruleset.displayName}. Current record: ${fighter.progress.record}.',
      },
      {
        'title': 'Gym watch: ${fighter.progress.gymName}',
        'body': 'Camp facilities are level ${fighter.progress.gymLevel}. Better facilities increase long-term development.',
      },
      {
        'title': 'Career clock keeps moving',
        'body': 'Week ${fighter.condition.week}, ${fighter.condition.year}. Training, rest and fights all advance the world timeline.',
      },
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('FIGHT WORLD NEWS')),
      body: ListView.separated(
        padding: const EdgeInsets.all(20),
        itemCount: stories.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final story = stories[index];
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(story['title']!, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(story['body']!, style: const TextStyle(color: Colors.white70)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
