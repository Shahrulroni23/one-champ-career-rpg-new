import 'dart:math';

import '../../../models/fight_result.dart';
import '../../../models/fighter_draft.dart';
import '../../../models/opponent.dart';

class FightEngine {
  FightEngine._();

  static final Random _random = Random();

  static FightResult simulate({
    required FighterDraft fighter,
    required Opponent opponent,
  }) {
    final playerCondition =
        (fighter.condition.energy + fighter.condition.health + fighter.condition.morale) /
        300.0;

    final playerStriking =
        (fighter.stats.jab +
                fighter.stats.cross +
                fighter.stats.hook +
                fighter.stats.kick +
                fighter.stats.accuracy +
                fighter.stats.power +
                fighter.stats.footwork) /
            7.0;

    final opponentStriking =
        (opponent.stats.jab +
                opponent.stats.cross +
                opponent.stats.hook +
                opponent.stats.kick +
                opponent.stats.accuracy +
                opponent.stats.power +
                opponent.stats.footwork) /
            7.0;

    final playerGrappling =
        (fighter.stats.wrestling +
                fighter.stats.takedown +
                fighter.stats.grappling +
                fighter.stats.submission +
                fighter.stats.groundControl +
                fighter.stats.fightIQ) /
            6.0;

    final opponentGrappling =
        (opponent.stats.wrestling +
                opponent.stats.takedown +
                opponent.stats.grappling +
                opponent.stats.submission +
                opponent.stats.groundControl +
                opponent.stats.fightIQ) /
            6.0;

    final playerDefense =
        (fighter.stats.defense +
                fighter.stats.chin +
                fighter.stats.durability +
                fighter.stats.composure +
                fighter.stats.cardio) /
            5.0;

    final opponentDefense =
        (opponent.stats.defense +
                opponent.stats.chin +
                opponent.stats.durability +
                opponent.stats.composure +
                opponent.stats.cardio) /
            5.0;

    final playerScore =
        ((playerStriking * 0.45) +
                (playerGrappling * 0.30) +
                (playerDefense * 0.25)) *
            (0.72 + playerCondition * 0.28) +
        (_random.nextDouble() * 14 - 7);

    final opponentScore =
        (opponentStriking * 0.45) +
        (opponentGrappling * 0.30) +
        (opponentDefense * 0.25) +
        (_random.nextDouble() * 14 - 7);

    final difference = playerScore - opponentScore;
    final summary = <String>[];

    for (var round = 1; round <= 3; round++) {
      final p = playerScore + (_random.nextDouble() * 12 - 6);
      final o = opponentScore + (_random.nextDouble() * 12 - 6);
      if (p > o + 7) {
        summary.add('Round $round: ${fighter.name} controls the action and lands the cleaner offense.');
      } else if (o > p + 7) {
        summary.add('Round $round: ${opponent.name} pushes the pace and wins the exchanges.');
      } else {
        summary.add('Round $round: Very close round with both fighters having strong moments.');
      }
    }

    FightOutcome outcome;
    String method;
    int round;

    if (difference > 15) {
      outcome = FightOutcome.win;
      method = playerStriking >= playerGrappling ? 'TKO' : 'SUBMISSION';
      round = 1 + _random.nextInt(3);
    } else if (difference > 3) {
      outcome = FightOutcome.win;
      method = 'UNANIMOUS DECISION';
      round = 3;
    } else if (difference < -15) {
      outcome = FightOutcome.loss;
      method = opponentStriking >= opponentGrappling ? 'TKO' : 'SUBMISSION';
      round = 1 + _random.nextInt(3);
    } else if (difference < -3) {
      outcome = FightOutcome.loss;
      method = 'UNANIMOUS DECISION';
      round = 3;
    } else {
      final roll = _random.nextDouble();
      if (roll < 0.45) {
        outcome = FightOutcome.win;
        method = 'SPLIT DECISION';
      } else if (roll < 0.90) {
        outcome = FightOutcome.loss;
        method = 'SPLIT DECISION';
      } else {
        outcome = FightOutcome.draw;
        method = 'MAJORITY DRAW';
      }
      round = 3;
    }

    final purse = 500 + (fighter.progress.wins * 250) + _random.nextInt(500);
    final fansChange = switch (outcome) {
      FightOutcome.win => 120 + _random.nextInt(180),
      FightOutcome.loss => 20 + _random.nextInt(50),
      FightOutcome.draw => 50 + _random.nextInt(80),
    };

    return FightResult(
      outcome: outcome,
      method: method,
      round: round,
      summary: summary,
      purse: purse,
      fansChange: fansChange,
    );
  }
}
