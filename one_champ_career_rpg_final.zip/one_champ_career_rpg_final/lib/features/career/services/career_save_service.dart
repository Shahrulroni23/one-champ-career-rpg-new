import 'package:hive/hive.dart';

import '../../../models/aggression.dart';
import '../../../models/career_progress.dart';
import '../../../models/fight_iq.dart';
import '../../../models/fight_pace.dart';
import '../../../models/fighter_condition.dart';
import '../../../models/fighter_draft.dart';
import '../../../models/fighter_gender.dart';
import '../../../models/fighter_stats.dart';
import '../../../models/fighting_style.dart';
import '../../../models/ruleset.dart';
import '../../../models/stance.dart';
import '../../../models/weight_class.dart';

class CareerSaveService {
  CareerSaveService._();

  static const String _boxName = 'career_box';
  static const String _careerKey = 'active_career';

  static Box<Map> get _box => Hive.box<Map>(_boxName);

  static Future<void> saveCareer(FighterDraft fighter) async {
    await _box.put(
      _careerKey,
      <String, dynamic>{
        'name': fighter.name,
        'nickname': fighter.nickname,
        'country': fighter.country,
        'gender': fighter.gender.name,
        'age': fighter.age,
        'ruleset': fighter.ruleset.name,
        'weightClass': fighter.weightClass.name,
        'height': fighter.height,
        'reach': fighter.reach,
        'stance': fighter.stance.name,
        'fightingStyle': fighter.fightingStyle.name,
        'fightPace': fighter.fightPace.name,
        'fightIQ': fighter.fightIQ.name,
        'aggression': fighter.aggression.name,
        'condition': <String, dynamic>{
          'energy': fighter.condition.energy,
          'health': fighter.condition.health,
          'morale': fighter.condition.morale,
          'weight': fighter.condition.weight,
          'year': fighter.condition.year,
          'week': fighter.condition.week,
          'day': fighter.condition.day,
        },
        'progress': <String, dynamic>{
          'wins': fighter.progress.wins,
          'losses': fighter.progress.losses,
          'draws': fighter.progress.draws,
          'money': fighter.progress.money,
          'fans': fighter.progress.fans,
          'popularity': fighter.progress.popularity,
          'rank': fighter.progress.rank,
        },
        'stats': <String, dynamic>{
          'power': fighter.stats.power,
          'speed': fighter.stats.speed,
          'strength': fighter.stats.strength,
          'cardio': fighter.stats.cardio,
          'recovery': fighter.stats.recovery,
          'chin': fighter.stats.chin,
          'heart': fighter.stats.heart,
          'durability': fighter.stats.durability,
          'jab': fighter.stats.jab,
          'cross': fighter.stats.cross,
          'hook': fighter.stats.hook,
          'kick': fighter.stats.kick,
          'elbow': fighter.stats.elbow,
          'knee': fighter.stats.knee,
          'accuracy': fighter.stats.accuracy,
          'defense': fighter.stats.defense,
          'footwork': fighter.stats.footwork,
          'wrestling': fighter.stats.wrestling,
          'clinch': fighter.stats.clinch,
          'takedown': fighter.stats.takedown,
          'takedownDefense': fighter.stats.takedownDefense,
          'groundControl': fighter.stats.groundControl,
          'grappling': fighter.stats.grappling,
          'submission': fighter.stats.submission,
          'submissionDefense': fighter.stats.submissionDefense,
          'scramble': fighter.stats.scramble,
          'fightIQ': fighter.stats.fightIQ,
          'composure': fighter.stats.composure,
          'killerInstinct': fighter.stats.killerInstinct,
        },
      },
    );
  }

  static FighterDraft? loadCareer() {
    final rawData = _box.get(_careerKey);
    if (rawData == null) return null;

    final data = Map<String, dynamic>.from(rawData);
    final statsData = _map(data['stats']);
    final conditionData = _map(data['condition']);
    final progressData = _map(data['progress']);

    return FighterDraft(
      name: data['name'] as String? ?? '',
      nickname: data['nickname'] as String? ?? '',
      country: data['country'] as String? ?? '',
      gender: FighterGender.values.firstWhere(
        (value) => value.name == data['gender'],
        orElse: () => FighterGender.male,
      ),
      age: data['age'] as int? ?? 18,
      ruleset: Ruleset.values.firstWhere(
        (value) => value.name == data['ruleset'],
        orElse: () => Ruleset.mma,
      ),
      weightClass: WeightClass.values.firstWhere(
        (value) => value.name == data['weightClass'],
        orElse: () => WeightClass.flyweight,
      ),
      height: data['height'] as int? ?? 170,
      reach: data['reach'] as int? ?? 175,
      stance: Stance.values.firstWhere(
        (value) => value.name == data['stance'],
        orElse: () => Stance.orthodox,
      ),
      fightingStyle: FightingStyle.values.firstWhere(
        (value) => value.name == data['fightingStyle'],
        orElse: () => FightingStyle.balanced,
      ),
      fightPace: FightPace.values.firstWhere(
        (value) => value.name == data['fightPace'],
        orElse: () => FightPace.balanced,
      ),
      fightIQ: FightIQ.values.firstWhere(
        (value) => value.name == data['fightIQ'],
        orElse: () => FightIQ.average,
      ),
      aggression: Aggression.values.firstWhere(
        (value) => value.name == data['aggression'],
        orElse: () => Aggression.medium,
      ),
      condition: FighterCondition(
        energy: conditionData['energy'] as int? ?? 100,
        health: conditionData['health'] as int? ?? 100,
        morale: conditionData['morale'] as int? ?? 80,
        weight: (conditionData['weight'] as num?)?.toDouble() ?? 70.0,
        year: conditionData['year'] as int? ?? 2026,
        week: conditionData['week'] as int? ?? 1,
        day: conditionData['day'] as int? ?? 1,
      ),
      progress: CareerProgress(
        wins: progressData['wins'] as int? ?? 0,
        losses: progressData['losses'] as int? ?? 0,
        draws: progressData['draws'] as int? ?? 0,
        money: progressData['money'] as int? ?? 0,
        fans: progressData['fans'] as int? ?? 0,
        popularity: progressData['popularity'] as int? ?? 1,
        rank: progressData['rank'] as int? ?? 0,
      ),
      stats: FighterStats(
        power: statsData['power'] as int? ?? 60,
        speed: statsData['speed'] as int? ?? 60,
        strength: statsData['strength'] as int? ?? 60,
        cardio: statsData['cardio'] as int? ?? 60,
        recovery: statsData['recovery'] as int? ?? 60,
        chin: statsData['chin'] as int? ?? 60,
        heart: statsData['heart'] as int? ?? 60,
        durability: statsData['durability'] as int? ?? 60,
        jab: statsData['jab'] as int? ?? 60,
        cross: statsData['cross'] as int? ?? 60,
        hook: statsData['hook'] as int? ?? 60,
        kick: statsData['kick'] as int? ?? 60,
        elbow: statsData['elbow'] as int? ?? 60,
        knee: statsData['knee'] as int? ?? 60,
        accuracy: statsData['accuracy'] as int? ?? 60,
        defense: statsData['defense'] as int? ?? 60,
        footwork: statsData['footwork'] as int? ?? 60,
        wrestling: statsData['wrestling'] as int? ?? 60,
        clinch: statsData['clinch'] as int? ?? 60,
        takedown: statsData['takedown'] as int? ?? 60,
        takedownDefense: statsData['takedownDefense'] as int? ?? 60,
        groundControl: statsData['groundControl'] as int? ?? 60,
        grappling: statsData['grappling'] as int? ?? 60,
        submission: statsData['submission'] as int? ?? 60,
        submissionDefense: statsData['submissionDefense'] as int? ?? 60,
        scramble: statsData['scramble'] as int? ?? 60,
        fightIQ: statsData['fightIQ'] as int? ?? 60,
        composure: statsData['composure'] as int? ?? 60,
        killerInstinct: statsData['killerInstinct'] as int? ?? 60,
      ),
    );
  }

  static Map<String, dynamic> _map(dynamic raw) {
    if (raw is Map) {
      return Map<String, dynamic>.from(raw);
    }
    return <String, dynamic>{};
  }

  static bool hasCareer() => _box.containsKey(_careerKey);

  static Future<void> deleteCareer() async {
    await _box.delete(_careerKey);
  }
}
