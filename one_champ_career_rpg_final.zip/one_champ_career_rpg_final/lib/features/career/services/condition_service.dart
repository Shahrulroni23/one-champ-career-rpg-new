import '../../../models/fighter_condition.dart';

class ConditionService {
  ConditionService._();

  static FighterCondition nextDay(FighterCondition condition) {
    int day = condition.day + 1;
    int week = condition.week;
    int year = condition.year;

    if (day > 7) {
      day = 1;
      week++;
    }

    if (week > 52) {
      week = 1;
      year++;
    }

    return condition.copyWith(
      day: day,
      week: week,
      year: year,
    );
  }

  static FighterCondition rest(FighterCondition condition) {
    return nextDay(
      condition.copyWith(
        energy: _cap(condition.energy + 30),
        health: _cap(condition.health + 12),
        morale: _cap(condition.morale + 5),
      ),
    );
  }

  static FighterCondition afterTraining(
    FighterCondition condition, {
    int energyCost = 10,
  }) {
    return nextDay(
      condition.copyWith(
        energy: _floor(condition.energy - energyCost),
        morale: _floor(condition.morale - 1),
      ),
    );
  }

  static FighterCondition afterFight(
    FighterCondition condition, {
    required bool won,
  }) {
    return nextDay(
      condition.copyWith(
        energy: _floor(condition.energy - 35),
        health: _floor(condition.health - (won ? 12 : 22)),
        morale: _cap(condition.morale + (won ? 8 : -6)),
      ),
    );
  }

  static int _cap(int value) {
    if (value > 100) return 100;
    if (value < 0) return 0;
    return value;
  }

  static int _floor(int value) => value < 0 ? 0 : value;
}
