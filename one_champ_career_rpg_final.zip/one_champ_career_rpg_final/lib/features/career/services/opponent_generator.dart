import 'dart:math';

import '../../../models/fighter_draft.dart';
import '../../../models/fighting_style.dart';
import '../../../models/opponent.dart';
import '../../../services/fighter_stats_generator.dart';

class OpponentGenerator {
  OpponentGenerator._();

  static final Random _random = Random();

  static const _firstNames = [
    'Alex', 'Daniel', 'Rizal', 'Kenji', 'Arman', 'Lucas', 'Takeru',
    'Farid', 'Diego', 'Nathan', 'Haris', 'Ren', 'Somsak', 'Jin',
  ];

  static const _lastNames = [
    'Silva', 'Tanaka', 'Rahman', 'Lee', 'Santos', 'Morgan', 'Khan',
    'Yamada', 'Petrov', 'Lim', 'Rodriguez', 'Aziz', 'Park', 'Sato',
  ];

  static const _countries = [
    'Malaysia', 'Thailand', 'Japan', 'Brazil', 'USA', 'South Korea',
    'Indonesia', 'Philippines', 'Russia', 'Singapore',
  ];

  static Opponent generate(FighterDraft fighter) {
    final style = FightingStyle.values[_random.nextInt(FightingStyle.values.length)];
    final base = FighterStatsGenerator.generate(style);

    final playerOvr = fighter.stats.overall;
    final adjustment = _random.nextInt(9) - 4;
    final targetOvr = (playerOvr + adjustment).clamp(48, 88);

    int scale(int value) {
      final delta = targetOvr - 60;
      return (value + delta).clamp(35, 95);
    }

    final stats = base.copyWith(
      power: scale(base.power),
      speed: scale(base.speed),
      strength: scale(base.strength),
      cardio: scale(base.cardio),
      recovery: scale(base.recovery),
      chin: scale(base.chin),
      heart: scale(base.heart),
      durability: scale(base.durability),
      jab: scale(base.jab),
      cross: scale(base.cross),
      hook: scale(base.hook),
      kick: scale(base.kick),
      elbow: scale(base.elbow),
      knee: scale(base.knee),
      accuracy: scale(base.accuracy),
      defense: scale(base.defense),
      footwork: scale(base.footwork),
      wrestling: scale(base.wrestling),
      clinch: scale(base.clinch),
      takedown: scale(base.takedown),
      takedownDefense: scale(base.takedownDefense),
      groundControl: scale(base.groundControl),
      grappling: scale(base.grappling),
      submission: scale(base.submission),
      submissionDefense: scale(base.submissionDefense),
      scramble: scale(base.scramble),
      fightIQ: scale(base.fightIQ),
      composure: scale(base.composure),
      killerInstinct: scale(base.killerInstinct),
    );

    final wins = _random.nextInt(9);
    final losses = _random.nextInt(4);

    return Opponent(
      name:
          '${_firstNames[_random.nextInt(_firstNames.length)]} '
          '${_lastNames[_random.nextInt(_lastNames.length)]}',
      country: _countries[_random.nextInt(_countries.length)],
      age: 19 + _random.nextInt(14),
      weightClass: fighter.weightClass,
      style: style,
      stats: stats,
      wins: wins,
      losses: losses,
    );
  }
}
