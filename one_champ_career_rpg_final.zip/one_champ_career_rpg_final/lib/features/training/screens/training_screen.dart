import 'package:flutter/material.dart';

import '../../../models/fighter_draft.dart';
import '../../../models/ruleset.dart';
import '../../career/screens/career_dashboard_screen.dart';
import '../../career/services/career_save_service.dart';
import '../../career/services/condition_service.dart';
import '../services/training_service.dart';

class TrainingScreen extends StatefulWidget {
  const TrainingScreen({
    required this.fighter,
    super.key,
  });

  final FighterDraft fighter;

  @override
  State<TrainingScreen> createState() => _TrainingScreenState();
}

class _TrainingScreenState extends State<TrainingScreen> {
  bool _isTraining = false;

  Future<void> _showTrainingReport({
    required FighterDraft fighter,
    required String sessionTitle,
    required String resultMessage,
  }) async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'TRAINING COMPLETE',
            textAlign: TextAlign.center,
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.fitness_center, size: 48),
                const SizedBox(height: 16),
                Text(
                  sessionTitle,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 16),
                Text(resultMessage, textAlign: TextAlign.center),
                const SizedBox(height: 20),
                const Divider(),
                _ReportRow(
                  title: 'Energy',
                  value: '${fighter.condition.energy} / 100',
                ),
                _ReportRow(
                  title: 'Health',
                  value: '${fighter.condition.health} / 100',
                ),
                _ReportRow(
                  title: 'Morale',
                  value: '${fighter.condition.morale} / 100',
                ),
                _ReportRow(
                  title: 'Date',
                  value:
                      '${_dayName(fighter.condition.day)} • '
                      'W${fighter.condition.week} • '
                      '${fighter.condition.year}',
                ),
              ],
            ),
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('CONTINUE'),
            ),
          ],
        );
      },
    );
  }

  String _dayName(int day) {
    const days = [
      'Monday', 'Tuesday', 'Wednesday', 'Thursday',
      'Friday', 'Saturday', 'Sunday',
    ];
    return days[day.clamp(1, 7) - 1];
  }

  Future<void> _completeTraining({
    required FighterDraft updatedFighter,
    required String sessionTitle,
    required String resultMessage,
    int energyCost = 10,
  }) async {
    if (_isTraining) return;

    if (widget.fighter.condition.energy < energyCost) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Not enough energy. Take a rest day.'),
        ),
      );
      return;
    }

    setState(() => _isTraining = true);

    final fighterAfterCondition = updatedFighter.copyWith(
      condition: ConditionService.afterTraining(
        updatedFighter.condition,
        energyCost: energyCost,
      ),
    );

    await CareerSaveService.saveCareer(fighterAfterCondition);
    if (!mounted) return;

    await _showTrainingReport(
      fighter: fighterAfterCondition,
      sessionTitle: sessionTitle,
      resultMessage: resultMessage,
    );

    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute<void>(
        builder: (_) => CareerDashboardScreen(
          fighter: fighterAfterCondition,
        ),
      ),
    );
  }

  Future<void> _trainCardio() async {
    await _completeTraining(
      updatedFighter: TrainingService.cardio(widget.fighter),
      sessionTitle: 'CARDIO SESSION',
      resultMessage: 'Cardio +2\nRecovery +1\nHeart +1\nEnergy -10',
    );
  }

  Future<void> _trainStriking() async {
    await _completeTraining(
      updatedFighter: TrainingService.striking(widget.fighter),
      sessionTitle: 'STRIKING SESSION',
      resultMessage: 'Jab +1\nCross +1\nHook +1\nAccuracy +1\nEnergy -10',
    );
  }

  Future<void> _trainWrestling() async {
    await _completeTraining(
      updatedFighter: TrainingService.wrestling(widget.fighter),
      sessionTitle: 'WRESTLING SESSION',
      resultMessage:
          'Wrestling +2\nTakedown +2\nGround Control +1\nEnergy -10',
    );
  }

  Future<void> _trainGrappling() async {
    await _completeTraining(
      updatedFighter: TrainingService.grappling(widget.fighter),
      sessionTitle: 'GRAPPLING SESSION',
      resultMessage: 'Grappling +1\nSubmission +2\nScramble +1\nEnergy -10',
    );
  }

  Future<void> _trainSparring() async {
    await _completeTraining(
      updatedFighter: TrainingService.sparring(widget.fighter),
      sessionTitle: 'SPARRING SESSION',
      resultMessage:
          'Defense +1\nFootwork +1\nFight IQ +1\nComposure +1\nEnergy -15',
      energyCost: 15,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('TRAINING')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                widget.fighter.name,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                widget.fighter.ruleset.displayName,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              Text(
                'Energy ${widget.fighter.condition.energy} • '
                'Health ${widget.fighter.condition.health} • '
                'Morale ${widget.fighter.condition.morale}',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70),
              ),
              const SizedBox(height: 8),
              Text(
                '${_dayName(widget.fighter.condition.day)} • '
                'Week ${widget.fighter.condition.week} • '
                '${widget.fighter.condition.year}',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                onPressed: _isTraining ? null : _trainCardio,
                child: const Text('CARDIO  •  -10 ENERGY'),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: _isTraining ? null : _trainStriking,
                child: const Text('STRIKING  •  -10 ENERGY'),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: _isTraining ? null : _trainWrestling,
                child: const Text('WRESTLING  •  -10 ENERGY'),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: _isTraining ? null : _trainGrappling,
                child: const Text('GRAPPLING  •  -10 ENERGY'),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: _isTraining ? null : _trainSparring,
                child: const Text('SPARRING  •  -15 ENERGY'),
              ),
              const Spacer(),
              if (_isTraining)
                const Center(child: CircularProgressIndicator())
              else
                OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('BACK'),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ReportRow extends StatelessWidget {
  const _ReportRow({
    required this.title,
    required this.value,
  });

  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(child: Text(title)),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}
