import '../../../models/fighter_draft.dart';

class TrainingService {
  TrainingService._();

  static const int _maxStat = 99;

  static int _bonus(FighterDraft fighter) => fighter.progress.trainingBonus;

  static FighterDraft cardio(FighterDraft fighter) {
    return fighter.copyWith(
      stats: fighter.stats.copyWith(
        cardio: _increase(fighter.stats.cardio, 2 + _bonus(fighter)),
        recovery: _increase(fighter.stats.recovery, 1),
        heart: _increase(fighter.stats.heart, 1),
      ),
    );
  }

  static FighterDraft striking(FighterDraft fighter) {
    return fighter.copyWith(
      stats: fighter.stats.copyWith(
        jab: _increase(fighter.stats.jab, 1 + _bonus(fighter)),
        cross: _increase(fighter.stats.cross, 1),
        hook: _increase(fighter.stats.hook, 1),
        accuracy: _increase(fighter.stats.accuracy, 1),
      ),
    );
  }

  static FighterDraft wrestling(FighterDraft fighter) {
    return fighter.copyWith(
      stats: fighter.stats.copyWith(
        wrestling: _increase(fighter.stats.wrestling, 2 + _bonus(fighter)),
        takedown: _increase(fighter.stats.takedown, 2),
        groundControl: _increase(fighter.stats.groundControl, 1),
      ),
    );
  }

  static FighterDraft grappling(FighterDraft fighter) {
    return fighter.copyWith(
      stats: fighter.stats.copyWith(
        grappling: _increase(fighter.stats.grappling, 1),
        submission: _increase(fighter.stats.submission, 2 + _bonus(fighter)),
        scramble: _increase(fighter.stats.scramble, 1),
      ),
    );
  }

  static FighterDraft sparring(FighterDraft fighter) {
    return fighter.copyWith(
      stats: fighter.stats.copyWith(
        defense: _increase(fighter.stats.defense, 1),
        footwork: _increase(fighter.stats.footwork, 1),
        fightIQ: _increase(fighter.stats.fightIQ, 1 + _bonus(fighter)),
        composure: _increase(fighter.stats.composure, 1),
      ),
    );
  }

  static int _increase(int value, int amount) {
    final result = value + amount;
    return result > _maxStat ? _maxStat : result;
  }
}
