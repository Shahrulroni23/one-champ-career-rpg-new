import 'package:flutter/material.dart';

import '../../../models/aggression.dart';
import '../../../models/fight_iq.dart';
import '../../../models/fight_pace.dart';
import '../../../models/fighter_draft.dart';
import '../../../models/fighter_gender.dart';
import '../../../models/fighting_style.dart';
import '../../../models/ruleset.dart';
import '../../../models/stance.dart';
import '../../../models/weight_class.dart';
import '../../../widgets/summary_tile.dart';
import '../../career/screens/career_dashboard_screen.dart';
import '../../career/services/career_save_service.dart';

class FighterSummaryScreen extends StatelessWidget {
  const FighterSummaryScreen({
    required this.draft,
    super.key,
  });

  final FighterDraft draft;

  @override
  Widget build(BuildContext context) {
    const currentStep = 4;
    const totalSteps = 4;

    return Scaffold(
      appBar: AppBar(title: const Text('CREATE YOUR LEGACY')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const Text(
              'STEP $currentStep OF $totalSteps',
              style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2),
            ),
            const SizedBox(height: 12),
            const LinearProgressIndicator(value: 1),
            const SizedBox(height: 24),
            const Text(
              'CAREER SUMMARY',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: [
                  SummaryTile(title: 'Name', value: draft.name),
                  SummaryTile(
                    title: 'Nickname',
                    value: draft.nickname.isEmpty ? 'None' : draft.nickname,
                  ),
                  SummaryTile(title: 'Country', value: draft.country),
                  SummaryTile(title: 'Gender', value: draft.gender.displayName),
                  SummaryTile(title: 'Starting Age', value: '${draft.age}'),
                  SummaryTile(
                    title: 'Start Year',
                    value: '${draft.condition.year}',
                  ),
                  SummaryTile(
                    title: 'Ruleset',
                    value: draft.ruleset.displayName,
                  ),
                  SummaryTile(
                    title: 'Weight Class',
                    value: draft.weightClass.displayName,
                  ),
                  SummaryTile(title: 'Height', value: '${draft.height} cm'),
                  SummaryTile(title: 'Reach', value: '${draft.reach} cm'),
                  SummaryTile(title: 'Stance', value: draft.stance.displayName),
                  SummaryTile(
                    title: 'Fighting Style',
                    value: draft.fightingStyle.displayName,
                  ),
                  SummaryTile(
                    title: 'Preferred Pace',
                    value: draft.fightPace.displayName,
                  ),
                  SummaryTile(
                    title: 'Fight IQ',
                    value: draft.fightIQ.displayName,
                  ),
                  SummaryTile(
                    title: 'Aggression',
                    value: draft.aggression.displayName,
                  ),
                  SummaryTile(
                    title: 'Starting OVR',
                    value: '${draft.stats.overall}',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('BACK'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: ElevatedButton(
                    onPressed: () async {
                      await CareerSaveService.saveCareer(draft);
                      if (!context.mounted) return;

                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute<void>(
                          builder: (_) =>
                              CareerDashboardScreen(fighter: draft),
                        ),
                      );
                    },
                    child: const Text('START CAREER'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
