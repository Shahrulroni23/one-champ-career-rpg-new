import 'package:flutter/material.dart';

import '../../../models/fighter_gender.dart';
import '../../../models/ruleset.dart';
import 'fighter_physical_screen.dart';

class FighterBasicInfoScreen extends StatefulWidget {
  const FighterBasicInfoScreen({
    required this.ruleset,
    super.key,
  });

  final Ruleset ruleset;

  @override
  State<FighterBasicInfoScreen> createState() =>
      _FighterBasicInfoScreenState();
}

class _FighterBasicInfoScreenState extends State<FighterBasicInfoScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _nicknameController = TextEditingController();
  final _countryController = TextEditingController(text: 'Malaysia');

  FighterGender _selectedGender = FighterGender.male;
  int _selectedAge = 18;
  int _selectedYear = 2026;

  @override
  void dispose() {
    _nameController.dispose();
    _nicknameController.dispose();
    _countryController.dispose();
    super.dispose();
  }

  void _continue() {
    if (!_formKey.currentState!.validate()) return;

    Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => FighterPhysicalScreen(
          ruleset: widget.ruleset,
          name: _nameController.text.trim(),
          nickname: _nicknameController.text.trim(),
          country: _countryController.text.trim(),
          genderId: _selectedGender.name,
          age: _selectedAge,
          startYear: _selectedYear,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const currentStep = 1;
    const totalSteps = 4;

    return Scaffold(
      appBar: AppBar(title: const Text('CREATE YOUR LEGACY')),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(24),
            children: [
              const Text(
                'STEP $currentStep OF $totalSteps',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 12),
              const LinearProgressIndicator(value: currentStep / totalSteps),
              const SizedBox(height: 30),
              const Text(
                'BASIC INFORMATION',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Primary Ruleset: ${widget.ruleset.displayName}',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70),
              ),
              const SizedBox(height: 30),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Fighter Name',
                ),
                validator: (value) {
                  if (value == null || value.trim().length < 3) {
                    return 'Enter at least 3 characters';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _nicknameController,
                decoration: const InputDecoration(
                  labelText: 'Nickname',
                  hintText: 'Optional',
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _countryController,
                decoration: const InputDecoration(
                  labelText: 'Country',
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Enter country';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<FighterGender>(
                initialValue: _selectedGender,
                decoration: const InputDecoration(labelText: 'Gender'),
                items: FighterGender.values
                    .map(
                      (gender) => DropdownMenuItem(
                        value: gender,
                        child: Text(gender.displayName),
                      ),
                    )
                    .toList(),
                onChanged: (value) {
                  if (value != null) {
                    setState(() => _selectedGender = value);
                  }
                },
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<int>(
                initialValue: _selectedAge,
                decoration: const InputDecoration(labelText: 'Starting Age'),
                items: List.generate(
                  18,
                  (index) {
                    final age = 18 + index;
                    return DropdownMenuItem(
                      value: age,
                      child: Text('$age years old'),
                    );
                  },
                ),
                onChanged: (value) {
                  if (value != null) {
                    setState(() => _selectedAge = value);
                  }
                },
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<int>(
                initialValue: _selectedYear,
                decoration: const InputDecoration(
                  labelText: 'Career Start Year',
                ),
                items: List.generate(
                  36,
                  (index) {
                    final year = 2000 + index;
                    return DropdownMenuItem(
                      value: year,
                      child: Text(year.toString()),
                    );
                  },
                ),
                onChanged: (value) {
                  if (value != null) {
                    setState(() => _selectedYear = value);
                  }
                },
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: _continue,
                child: const Text('CONTINUE'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
