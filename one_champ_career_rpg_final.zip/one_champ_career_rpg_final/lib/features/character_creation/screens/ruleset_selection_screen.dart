import 'package:flutter/material.dart';

import '../../../models/ruleset.dart';
import 'fighter_basic_info_screen.dart';

class RulesetSelectionScreen extends StatelessWidget {
  const RulesetSelectionScreen({super.key});

  void _open(
    BuildContext context,
    Ruleset ruleset,
  ) {
    Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => FighterBasicInfoScreen(ruleset: ruleset),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SELECT RULESET')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 30),
          const Text(
            'CHOOSE YOUR PRIMARY RULESET',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Your ruleset shapes your training, opponents and fight style.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 40),
          _RulesetCard(
            title: 'MMA',
            description:
                'Striking, takedowns, ground control and submissions.',
            onPressed: () => _open(context, Ruleset.mma),
          ),
          const SizedBox(height: 16),
          _RulesetCard(
            title: 'MUAY THAI',
            description:
                'Punches, kicks, knees, elbows and clinch fighting.',
            onPressed: () => _open(context, Ruleset.muayThai),
          ),
          const SizedBox(height: 16),
          _RulesetCard(
            title: 'KICKBOXING',
            description:
                'Fast combinations, kicks, movement and limited clinch.',
            onPressed: () => _open(context, Ruleset.kickboxing),
          ),
        ],
      ),
    );
  }
}

class _RulesetCard extends StatelessWidget {
  const _RulesetCard({
    required this.title,
    required this.description,
    required this.onPressed,
  });

  final String title;
  final String description;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                description,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
