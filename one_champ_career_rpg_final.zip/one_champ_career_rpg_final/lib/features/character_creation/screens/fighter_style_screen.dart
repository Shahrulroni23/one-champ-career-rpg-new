import 'package:flutter/material.dart';

import '../../../models/aggression.dart';
import '../../../models/fight_iq.dart';
import '../../../models/fight_pace.dart';
import '../../../models/fighter_draft.dart';
import '../../../models/fighting_style.dart';
import '../../../services/fighter_stats_generator.dart';
import 'fighter_summary_screen.dart';

class FighterStyleScreen extends StatefulWidget {
  const FighterStyleScreen({
    required this.draft,
    super.key,
  });

  final FighterDraft draft;

  @override
  State<FighterStyleScreen> createState() => _FighterStyleScreenState();
}

class _FighterStyleScreenState extends State<FighterStyleScreen> {
  FightingStyle _selectedStyle = FightingStyle.balanced;
  FightPace _selectedPace = FightPace.balanced;
  FightIQ _selectedFightIQ = FightIQ.average;
  Aggression _selectedAggression = Aggression.medium;

  void _continue() {
    final updatedDraft = widget.draft.copyWith(
      fightingStyle: _selectedStyle,
      fightPace: _selectedPace,
      fightIQ: _selectedFightIQ,
      aggression: _selectedAggression,
      stats: FighterStatsGenerator.generate(_selectedStyle),
    );

    Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => FighterSummaryScreen(draft: updatedDraft),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const currentStep = 3;
    const totalSteps = 4;

    return Scaffold(
      appBar: AppBar(title: const Text('CREATE YOUR LEGACY')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const Text(
            'STEP $currentStep OF $totalSteps',
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2),
          ),
          const SizedBox(height: 12),
          const LinearProgressIndicator(value: currentStep / totalSteps),
          const SizedBox(height: 30),
          const Text(
            'FIGHTING PROFILE',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 30),
          DropdownButtonFormField<FightingStyle>(
            initialValue: _selectedStyle,
            decoration: const InputDecoration(
              labelText: 'Primary Fighting Style',
            ),
            items: FightingStyle.values
                .map(
                  (style) => DropdownMenuItem(
                    value: style,
                    child: Text(style.displayName),
                  ),
                )
                .toList(),
            onChanged: (value) {
              if (value != null) setState(() => _selectedStyle = value);
            },
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<FightPace>(
            initialValue: _selectedPace,
            decoration: const InputDecoration(labelText: 'Preferred Pace'),
            items: FightPace.values
                .map(
                  (pace) => DropdownMenuItem(
                    value: pace,
                    child: Text(pace.displayName),
                  ),
                )
                .toList(),
            onChanged: (value) {
              if (value != null) setState(() => _selectedPace = value);
            },
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<FightIQ>(
            initialValue: _selectedFightIQ,
            decoration: const InputDecoration(labelText: 'Fight IQ'),
            items: FightIQ.values
                .map(
                  (iq) => DropdownMenuItem(
                    value: iq,
                    child: Text(iq.displayName),
                  ),
                )
                .toList(),
            onChanged: (value) {
              if (value != null) setState(() => _selectedFightIQ = value);
            },
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<Aggression>(
            initialValue: _selectedAggression,
            decoration: const InputDecoration(labelText: 'Aggression'),
            items: Aggression.values
                .map(
                  (aggression) => DropdownMenuItem(
                    value: aggression,
                    child: Text(aggression.displayName),
                  ),
                )
                .toList(),
            onChanged: (value) {
              if (value != null) {
                setState(() => _selectedAggression = value);
              }
            },
          ),
          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: _continue,
            child: const Text('CONTINUE'),
          ),
        ],
      ),
    );
  }
}
