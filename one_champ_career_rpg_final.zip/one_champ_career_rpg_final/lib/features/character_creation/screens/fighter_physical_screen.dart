import 'package:flutter/material.dart';

import '../../../models/aggression.dart';
import '../../../models/career_progress.dart';
import '../../../models/fight_iq.dart';
import '../../../models/fight_pace.dart';
import '../../../models/fighter_condition.dart';
import '../../../models/fighter_draft.dart';
import '../../../models/fighter_gender.dart';
import '../../../models/fighting_style.dart';
import '../../../models/ruleset.dart';
import '../../../models/stance.dart';
import '../../../models/weight_class.dart';
import '../../../services/fighter_stats_generator.dart';
import 'fighter_style_screen.dart';

class FighterPhysicalScreen extends StatefulWidget {
  const FighterPhysicalScreen({
    required this.ruleset,
    required this.name,
    required this.nickname,
    required this.country,
    required this.genderId,
    required this.age,
    required this.startYear,
    super.key,
  });

  final Ruleset ruleset;
  final String name;
  final String nickname;
  final String country;
  final String genderId;
  final int age;
  final int startYear;

  @override
  State<FighterPhysicalScreen> createState() =>
      _FighterPhysicalScreenState();
}

class _FighterPhysicalScreenState extends State<FighterPhysicalScreen> {
  WeightClass _selectedWeightClass = WeightClass.flyweight;
  int _selectedHeight = 170;
  int _selectedReach = 175;
  Stance _selectedStance = Stance.orthodox;

  void _continue() {
    final condition = FighterCondition(
      energy: 100,
      health: 100,
      morale: 80,
      weight: _selectedWeightClass.targetWeightKg + 2.0,
      year: widget.startYear,
      week: 1,
      day: 1,
    );

    final draft = FighterDraft(
      ruleset: widget.ruleset,
      name: widget.name,
      nickname: widget.nickname,
      country: widget.country,
      gender: FighterGender.values.firstWhere(
        (gender) => gender.name == widget.genderId,
        orElse: () => FighterGender.male,
      ),
      age: widget.age,
      weightClass: _selectedWeightClass,
      height: _selectedHeight,
      reach: _selectedReach,
      stance: _selectedStance,
      fightingStyle: FightingStyle.balanced,
      fightPace: FightPace.balanced,
      fightIQ: FightIQ.average,
      aggression: Aggression.medium,
      stats: FighterStatsGenerator.generate(FightingStyle.balanced),
      condition: condition,
      progress: CareerProgress.beginner,
    );

    Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => FighterStyleScreen(draft: draft),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const currentStep = 2;
    const totalSteps = 4;

    return Scaffold(
      appBar: AppBar(title: const Text('CREATE YOUR LEGACY')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const Text(
            'STEP $currentStep OF $totalSteps',
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2),
          ),
          const SizedBox(height: 12),
          const LinearProgressIndicator(value: currentStep / totalSteps),
          const SizedBox(height: 30),
          const Text(
            'PHYSICAL ATTRIBUTES',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 30),
          DropdownButtonFormField<WeightClass>(
            initialValue: _selectedWeightClass,
            decoration: const InputDecoration(labelText: 'Weight Class'),
            items: WeightClass.values
                .map(
                  (weightClass) => DropdownMenuItem(
                    value: weightClass,
                    child: Text(weightClass.displayName),
                  ),
                )
                .toList(),
            onChanged: (value) {
              if (value != null) {
                setState(() => _selectedWeightClass = value);
              }
            },
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<int>(
            initialValue: _selectedHeight,
            decoration: const InputDecoration(labelText: 'Height'),
            items: List.generate(
              61,
              (index) {
                final height = 145 + index;
                return DropdownMenuItem(
                  value: height,
                  child: Text('$height cm'),
                );
              },
            ),
            onChanged: (value) {
              if (value != null) {
                setState(() => _selectedHeight = value);
              }
            },
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<int>(
            initialValue: _selectedReach,
            decoration: const InputDecoration(labelText: 'Reach'),
            items: List.generate(
              71,
              (index) {
                final reach = 145 + index;
                return DropdownMenuItem(
                  value: reach,
                  child: Text('$reach cm'),
                );
              },
            ),
            onChanged: (value) {
              if (value != null) {
                setState(() => _selectedReach = value);
              }
            },
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<Stance>(
            initialValue: _selectedStance,
            decoration: const InputDecoration(labelText: 'Stance'),
            items: Stance.values
                .map(
                  (stance) => DropdownMenuItem(
                    value: stance,
                    child: Text(stance.displayName),
                  ),
                )
                .toList(),
            onChanged: (value) {
              if (value != null) {
                setState(() => _selectedStance = value);
              }
            },
          ),
          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: _continue,
            child: const Text('CONTINUE'),
          ),
        ],
      ),
    );
  }
}
