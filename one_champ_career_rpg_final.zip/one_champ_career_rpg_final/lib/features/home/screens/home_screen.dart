import 'package:flutter/material.dart';

import '../../career/screens/career_menu_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              const Icon(
                Icons.sports_mma,
                size: 72,
              ),
              const SizedBox(height: 16),
              const Text(
                'ONE CHAMP',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 38,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 3,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'FORGE YOUR LEGACY',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 15,
                  letterSpacing: 4,
                  color: Colors.white70,
                ),
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => const CareerMenuScreen(),
                    ),
                  );
                },
                child: const Text('CAREER MODE'),
              ),
              const SizedBox(height: 14),
              ElevatedButton(
                onPressed: null,
                child: const Text('EXHIBITION — COMING SOON'),
              ),
              const SizedBox(height: 14),
              ElevatedButton(
                onPressed: null,
                child: const Text('HALL OF CHAMPIONS — COMING SOON'),
              ),
              const Spacer(),
              const Text(
                'Prototype 0.7',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white38),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
