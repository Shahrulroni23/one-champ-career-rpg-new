$ErrorActionPreference = "Stop"

Write-Host "=== ONE CHAMP setup ===" -ForegroundColor Cyan

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
    throw "Flutter is not available in PATH."
}

flutter create .
flutter pub get
flutter analyze

Write-Host ""
Write-Host "Setup complete. Run:" -ForegroundColor Green
Write-Host "flutter run"
