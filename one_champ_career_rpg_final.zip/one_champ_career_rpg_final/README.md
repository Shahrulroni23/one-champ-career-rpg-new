# ONE CHAMP V2 — Forge Your Legacy

This is a rebuilt Flutter source project based on the current design and gameplay direction.

## Included now

- Main menu
- Career menu
- New / Continue / Delete career
- Character creation wizard
  - Ruleset
  - Basic information
  - Physical attributes
  - Fighting profile
  - Career summary
- 29 fighter stats
- Archetype-based stats generator
- Hive save/load
- Career dashboard
- Energy / Health / Morale
- Year / Week / Day progression
- Training system
- Training report
- Rest day
- Basic fight-offer generator
- AI opponent generator
- Fight simulation alpha
- Record / money / fans / popularity progression

## Important

This environment did not have the Flutter SDK installed, so the source was assembled here but could not be compiled into an APK in this session.

If platform folders are missing, run this once in the project root:

```powershell
flutter create .
flutter pub get
flutter analyze
flutter run
```

There is also a `setup_project.ps1` helper.

## Locked backlog

These are intentionally not wired into the current core yet:

- Living World Timeline
- Dynasty / next generation
- Protégé / family-tree continuation
- Hall of Fame
- AI career simulation across decades
- Champion history / world history
- Real-fighter historical career mode
- Coaches, gyms, sponsors, contracts
- Advanced injuries / weight cutting / fight camps
- Full rankings and championship ecosystem


## V2 additions

- Premium career hub UI
- Real calendar date derived from career timeline
- Fighter aging based on start year
- Legacy score
- Persistent gym level and upgrade economy
- Gym-based training bonuses
- Compact fighter identity ratings
- Dedicated detailed fighter profile
- Dynamic career news screen
